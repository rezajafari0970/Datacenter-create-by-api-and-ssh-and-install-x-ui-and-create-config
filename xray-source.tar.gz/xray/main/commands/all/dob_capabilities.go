package all

import (
	"fmt"
	"github.com/xtls/xray-core/main/commands/base"
)

var cmdDOBCapabilities = &base.Command{
	UsageLine: "{{.Exec}} dob-capabilities",
	Short:     "Report verified Digital Ocean Bot transport extensions",
	Run: func(cmd *base.Command, args []string) {
		fmt.Println(`{"schema":1,"websocket_graceful_close":true,"tls_certificate_snapshot":true,"reality_fallback_bounded":true,"reality_handshake_deadline":true,"reality_fallback_max_connections":512,"reality_finalmask_fragment":true,"xhttp_vision_encryption":true}`)
	},
}

func init() { base.RootCommand.Commands = append(base.RootCommand.Commands, cmdDOBCapabilities) }
