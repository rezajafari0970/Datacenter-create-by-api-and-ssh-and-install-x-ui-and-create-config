module github.com/xtls/xray-core

go 1.27

require (
	github.com/apernet/quic-go v0.61.1-0.20260806010916-184d081eef3e
	github.com/cloudflare/circl v1.6.5
	github.com/ghodss/yaml v1.0.1-0.20220118164431-d8423dcdf344
	github.com/golang/mock v1.7.0-rc.1
	github.com/google/go-cmp v0.7.0
	github.com/google/uuid v1.6.0
	github.com/gorilla/websocket v1.5.3
	github.com/klauspost/cpuid/v2 v2.4.0
	github.com/libp2p/go-nat v1.0.1-0.20250821073202-01afc089f138
	github.com/miekg/dns v1.1.73
	github.com/pelletier/go-toml v1.9.5
	github.com/pion/stun/v3 v3.1.7
	github.com/pires/go-proxyproto v0.15.0
	github.com/refraction-networking/utls v1.8.3-0.20260301010127-aa6edf4b11af
	github.com/robfig/cron/v3 v3.0.1
	github.com/stretchr/testify v1.12.1
	github.com/vishvananda/netlink v1.3.1
	github.com/xtls/reality v0.0.0-20260908062103-8cdf7bf9c7f0
	github.com/yuin/gopher-lua v1.1.2
	go4.org/netipx v0.0.0-20231129151722-fdeea329fbba
	golang.org/x/crypto v0.57.0
	golang.org/x/exp v0.0.0-20240506185415-9bf2ced13842
	golang.org/x/net v0.59.0
	golang.org/x/sync v0.23.0
	golang.org/x/sys v0.48.0
	golang.zx2c4.com/wintun v0.0.0-20230126152724-0fa3db229ce2
	golang.zx2c4.com/wireguard v0.0.0-20250521234502-f333402bd9cb
	golang.zx2c4.com/wireguard/windows v1.1.1
	google.golang.org/grpc v1.84.0
	google.golang.org/protobuf v1.36.12
	gvisor.dev/gvisor v0.0.0-20260122175437-89a5d21be8f0
	h12.io/socks v1.0.3
	layeh.com/gopher-luar v1.0.11
	lukechampine.com/blake3 v1.4.1
	mvdan.cc/gofumpt v0.12.0
)

require (
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/google/btree v1.1.2 // indirect
	github.com/google/gopacket v1.1.19 // indirect
	github.com/huin/goupnp v1.2.0 // indirect
	github.com/jackpal/go-nat-pmp v1.0.2 // indirect
	github.com/juju/ratelimit v1.0.2 // indirect
	github.com/klauspost/compress v1.17.4 // indirect
	github.com/koron/go-ssdp v0.0.4 // indirect
	github.com/libp2p/go-netroute v0.2.1 // indirect
	github.com/pion/dtls/v3 v3.1.5 // indirect
	github.com/pion/logging v0.2.4 // indirect
	github.com/pion/transport/v4 v4.1.0 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	github.com/vishvananda/netns v0.0.5 // indirect
	github.com/wlynxg/anet v0.0.5 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/crypto/x509roots/fallback v0.0.0-20261005185213-c3db4df58582 // indirect
	golang.org/x/text v0.42.0 // indirect
	golang.org/x/time v0.14.0 // indirect
	golang.org/x/tools v0.49.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20260706201446-f0a921348800 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
)

replace github.com/xtls/reality => ./third_party/reality
