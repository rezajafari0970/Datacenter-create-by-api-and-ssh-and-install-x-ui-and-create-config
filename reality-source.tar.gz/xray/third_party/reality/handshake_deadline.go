package reality

import (
	"net"
	"sync/atomic"
	"time"
)

// handshakeDeadline interrupts clients which never finish reading or writing
// their handshake. Releasing it transfers lifetime ownership to authenticated
// transport or the fallback's separate idle clock.
type handshakeDeadline struct {
	state atomic.Int32 // 0=pending, 1=released, 2=expired
	timer *time.Timer
}

func newHandshakeDeadline(client, target net.Conn, timeout time.Duration) *handshakeDeadline {
	d := &handshakeDeadline{}
	d.timer = time.AfterFunc(timeout, func() {
		if d.state.CompareAndSwap(0, 2) {
			closeExpiredConn(client)
			closeExpiredConn(target)
		}
	})
	return d
}
func (d *handshakeDeadline) release() bool {
	if d.state.CompareAndSwap(0, 1) {
		d.timer.Stop()
		return true
	}
	return d.state.Load() == 1
}

// An expired unauthenticated connection has no remaining useful payload.
// Abort TCP queues as well as userspace IO instead of leaving orphaned
// retransmission buffers charged to the kernel after Close returns.
func closeExpiredConn(c net.Conn) {
	if tcp, ok := c.(interface{ SetLinger(int) error }); ok {
		_ = tcp.SetLinger(0)
	}
	_ = c.Close()
}
