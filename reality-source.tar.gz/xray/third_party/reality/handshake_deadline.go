package reality

import (
	"net"
	"sync/atomic"
	"time"
)

// handshakeDeadline interrupts clients which never finish reading or writing
// their handshake. Releasing it transfers lifetime ownership to authenticated
// transport or the fallback's separate idle clock.
type handshakeDeadline struct {
	state atomic.Int32 // 0=pending, 1=released, 2=expired
	timer *time.Timer
}

func newHandshakeDeadline(client, target net.Conn, timeout time.Duration) *handshakeDeadline {
	d := &handshakeDeadline{}
	d.timer = time.AfterFunc(timeout, func() {
		if d.state.CompareAndSwap(0, 2) {
			client.Close()
			target.Close()
		}
	})
	return d
}
func (d *handshakeDeadline) release() bool {
	if d.state.CompareAndSwap(0, 1) {
		d.timer.Stop()
		return true
	}
	return d.state.Load() == 1
}
