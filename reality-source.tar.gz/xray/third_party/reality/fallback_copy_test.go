package reality

import (
	"bytes"
	"context"
	"io"
	"net"
	"sync"
	"testing"
	"time"
)

func TestFallbackIdleClosesBothDirections(t *testing.T) {
	a, ap := net.Pipe()
	b, bp := net.Pipe()
	defer ap.Close()
	defer bp.Close()
	f := newFallbackCopier(a, b, 30*time.Millisecond)
	defer f.stop()
	done := make(chan struct{}, 2)
	go func() { f.copy(b, a, &LimitFallback{}); done <- struct{}{} }()
	go func() { f.copy(a, b, &LimitFallback{}); done <- struct{}{} }()
	for i := 0; i < 2; i++ {
		select {
		case <-done:
		case <-time.After(time.Second):
			t.Fatal("idle forwarding retained a connection")
		}
	}
}

type forbiddenFastPath struct{ net.Conn }

func (c forbiddenFastPath) WriteTo(io.Writer) (int64, error) {
	panic("unauthenticated splice WriterTo used")
}
func (c forbiddenFastPath) ReadFrom(io.Reader) (int64, error) {
	panic("unauthenticated splice ReaderFrom used")
}
func TestFallbackUnidirectionalActivityAndBoundedCopy(t *testing.T) {
	a, ap := net.Pipe()
	b, bp := net.Pipe()
	defer ap.Close()
	defer bp.Close()
	f := newFallbackCopier(a, b, 120*time.Millisecond)
	defer f.stop()
	done := make(chan struct{}, 2)
	go func() { f.copy(forbiddenFastPath{b}, forbiddenFastPath{a}, &LimitFallback{}); done <- struct{}{} }()
	go func() { f.copy(forbiddenFastPath{a}, forbiddenFastPath{b}, &LimitFallback{}); done <- struct{}{} }()
	payload := bytes.Repeat([]byte("fallback-data"), 4096)
	received := make(chan error, 1)
	go func() {
		for i := 0; i < 12; i++ {
			v := make([]byte, len(payload))
			if _, e := io.ReadFull(bp, v); e != nil {
				received <- e
				return
			}
			if !bytes.Equal(v, payload) {
				received <- io.ErrUnexpectedEOF
				return
			}
		}
		received <- nil
	}()
	for i := 0; i < 12; i++ {
		if _, e := ap.Write(payload); e != nil {
			t.Fatal(e)
		}
		time.Sleep(25 * time.Millisecond)
	}
	if e := <-received; e != nil {
		t.Fatal(e)
	}
	select {
	case <-done:
		t.Fatal("one-way active fallback closed")
	default:
	}
	for i := 0; i < 2; i++ {
		select {
		case <-done:
		case <-time.After(time.Second):
			t.Fatal("forwarding did not expire after activity stopped")
		}
	}
}
func TestUnusedFallbackTimerDoesNotCloseAuthenticatedTransport(t *testing.T) {
	a, ap := net.Pipe()
	b, bp := net.Pipe()
	defer a.Close()
	defer ap.Close()
	defer b.Close()
	defer bp.Close()
	f := newFallbackCopier(a, b, time.Millisecond)
	f.stop()
	time.Sleep(5 * time.Millisecond)
	done := make(chan error, 1)
	go func() { _, e := ap.Write([]byte("x")); done <- e }()
	var v [1]byte
	if _, e := io.ReadFull(a, v[:]); e != nil {
		t.Fatal(e)
	}
	if e := <-done; e != nil {
		t.Fatal(e)
	}
}
func TestFallbackStopAndExpiryRace(t *testing.T) {
	for i := 0; i < 50; i++ {
		a, ap := net.Pipe()
		b, bp := net.Pipe()
		f := newFallbackCopier(a, b, time.Microsecond)
		f.touch()
		var w sync.WaitGroup
		w.Add(2)
		go func() { defer w.Done(); f.touch() }()
		go func() { defer w.Done(); f.stop() }()
		w.Wait()
		a.Close()
		ap.Close()
		b.Close()
		bp.Close()
	}
}
func TestServerInvalidTLSFallbackPreservesHalfCloseResponse(t *testing.T) {
	target, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	defer target.Close()
	request := []byte("GET / HTTP/1.1\r\nHost: example.test\r\n\r\n")
	response := []byte("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
	targetDone := make(chan error, 1)
	go func() {
		c, e := target.Accept()
		if e != nil {
			targetDone <- e
			return
		}
		defer c.Close()
		c.SetDeadline(time.Now().Add(2 * time.Second))
		got, e := io.ReadAll(c)
		if e == nil && !bytes.Equal(got, request) {
			e = io.ErrUnexpectedEOF
		}
		if e == nil {
			_, e = c.Write(response)
		}
		if tc, ok := c.(*net.TCPConn); ok {
			tc.CloseWrite()
		}
		targetDone <- e
	}()
	listener, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	defer listener.Close()
	serverDone := make(chan error, 1)
	go func() {
		c, e := listener.Accept()
		if e != nil {
			serverDone <- e
			return
		}
		c.SetDeadline(time.Now().Add(2 * time.Second))
		_, e = Server(context.Background(), c, &Config{Type: "tcp", Dest: target.Addr().String(), DialContext: (&net.Dialer{}).DialContext})
		serverDone <- e
	}()
	client, e := net.Dial("tcp", listener.Addr().String())
	if e != nil {
		t.Fatal(e)
	}
	defer client.Close()
	client.SetDeadline(time.Now().Add(2 * time.Second))
	if _, e = client.Write(request); e != nil {
		t.Fatal(e)
	}
	client.(*net.TCPConn).CloseWrite()
	got, e := io.ReadAll(client)
	if e != nil {
		t.Fatal(e)
	}
	if !bytes.Equal(got, response) {
		t.Fatalf("fallback response mismatch: %q", got)
	}
	if e = <-targetDone; e != nil {
		t.Fatal(e)
	}
	select {
	case e = <-serverDone:
		if e == nil {
			t.Fatal("invalid handshake was accepted")
		}
	case <-time.After(3 * time.Second):
		t.Fatal("fallback server did not exit")
	}
}

func TestFallbackIdleCancelsRateLimitWait(t *testing.T) {
	a, ap := net.Pipe()
	b, bp := net.Pipe()
	defer ap.Close()
	defer bp.Close()
	f := newFallbackCopier(a, b, 30*time.Millisecond)
	defer f.stop()
	done := make(chan struct{})
	go func() { f.copy(b, a, &LimitFallback{BytesPerSec: 1, BurstBytesPerSec: 1}); close(done) }()
	go ap.Write(bytes.Repeat([]byte("x"), 16384))
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("rate-limit delay retained expired fallback")
	}
}
