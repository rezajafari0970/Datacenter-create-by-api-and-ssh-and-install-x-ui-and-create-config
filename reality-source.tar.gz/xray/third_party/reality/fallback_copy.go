package reality

import (
	"io"
	"net"
	"sync"
	"time"
)

// fallbackCopier bounds buffers and releases idle unauthenticated forwarding.
// Both directions share one activity clock: a download need not upload data to
// stay alive. Authenticated REALITY connections never start this timer.
type fallbackCopier struct {
	client, target net.Conn
	idle           time.Duration
	mu             sync.Mutex
	last           time.Time
	timer          *time.Timer
	stopped        bool
	done           chan struct{}
	onStart        func() bool
}

func newFallbackCopier(client, target net.Conn, idle time.Duration) *fallbackCopier {
	return &fallbackCopier{client: client, target: target, idle: idle, done: make(chan struct{})}
}

func (f *fallbackCopier) touch() {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.stopped {
		return
	}
	f.last = time.Now()
	if f.timer == nil {
		f.timer = time.AfterFunc(f.idle, f.expire)
	}
}
func (f *fallbackCopier) expire() {
	f.mu.Lock()
	if f.stopped {
		f.mu.Unlock()
		return
	}
	if remaining := f.idle - time.Since(f.last); remaining > 0 {
		f.timer.Reset(remaining)
		f.mu.Unlock()
		return
	}
	f.stopped = true
	close(f.done)
	f.mu.Unlock()
	// Interrupt both pending reads and writes; the owner joins both copy tasks.
	f.client.Close()
	f.target.Close()
}
func (f *fallbackCopier) stop() {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.stopped {
		return
	}
	f.stopped = true
	close(f.done)
	if f.timer != nil {
		f.timer.Stop()
	}
}

type fallbackReader struct {
	reader io.Reader
	owner  *fallbackCopier
}

func (r fallbackReader) Read(p []byte) (int, error) {
	n, e := r.reader.Read(p)
	if n > 0 {
		r.owner.touch()
	}
	return n, e
}

type fallbackWriter struct {
	writer io.Writer
	owner  *fallbackCopier
}

func (w fallbackWriter) Write(p []byte) (int, error) {
	n, e := w.writer.Write(p)
	if n > 0 {
		w.owner.touch()
	}
	return n, e
}
func (f *fallbackCopier) copy(dst, src net.Conn, limit *LimitFallback) (int64, error) {
	if f.onStart != nil && !f.onStart() {
		return 0, net.ErrClosed
	}
	f.touch()
	// Hide ReaderFrom/WriterTo to prevent Go's TCP splice path from allocating
	// large kernel pipe buffers for unauthenticated connections.
	reader := NewRatelimitedConn(src, limit)
	if limited, ok := reader.(*RatelimitedConn); ok {
		limited.cancel = f.done
	}
	return io.CopyBuffer(fallbackWriter{dst, f}, fallbackReader{reader, f}, make([]byte, 16*1024))
}
